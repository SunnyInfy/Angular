
Declare @FacilityID int, @OrderTypeID int, @OrderId int, @AggrigatePoolID int, @CustomerId int

SET @FacilityID=(select FacilityID from dbo.[Facility] where ShortName='VNG')
SET @AggrigatePoolID=(select AggregatePoolID from dbo.[AggregatePool] where AggregatePoolName='VNG')
--Insert the data for Economic Curtailment OrderType
SET @OrderTypeID= (select OrderTypeID from dbo.[OrderType] where OrderTypeName='Economic Curtailment')

INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-25', '2022-02-25 10:00:00.000', GETDATE());

SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 



INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-08', '2022-02-08 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-09', '2022-02-09 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-12', '2022-02-12 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-16', '2022-02-16 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-23', '2022-02-23 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-24', '2022-02-24 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-26', '2022-02-26 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 

--Insert the data for Supply or Capacity Curtailment OrderType

SET @OrderTypeID= (select OrderTypeID from dbo.[OrderType] where OrderTypeName='Supply or Capacity Curtailment')

INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-03', '2022-02-03 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-10', '2022-02-10 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-13', '2022-02-13 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-15', '2022-02-15 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-17', '2022-02-17 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-18', '2022-02-18 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-22', '2022-02-22 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 



INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-28', '2022-02-28 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID])
VALUES (@OrderID, @AggrigatePoolID) 

--Insert the data for Operational Curtailment OrderType

SET @OrderTypeID= (select OrderTypeID from dbo.[OrderType] where OrderTypeName='Operational Curtailment')

INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-02', '2022-02-02 10:00:00.000', GETDATE());

SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Piedmont Hospital Tower 1')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Pilgrims Corporation - Ranger')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-05', '2022-02-05 10:00:00.000', GETDATE());

SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='1888 Mills LLC')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Quikrete Companies LLC')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);



INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-06', '2022-02-06 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Piedmont Hospital Tower 1')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='APS Partners, LLC - Boiler # 3')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-07', '2022-02-07 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)
SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='APS Partners, LLC - Boiler # 3')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Solvay Advanced Polymers, LLC')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-11', '2022-02-11 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)
		
SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='APS Partners, LLC - Boiler # 3')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='C W Matthews - Bolingbroke')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-14', '2022-02-14 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)
SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Piedmont Hospital Tower 1')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Quikrete Companies LLC')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-18', '2022-02-18 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)
SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='1888 Mills LLC')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='C W Matthews - Bolingbroke')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-20', '2022-02-20 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='C W Matthews - Garden City')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Vopak Terminals Savannah Inc')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-19', '2022-02-19 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)
SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='1888 Mills LLC')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Pilgrims Corporation - Ranger')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-04', '2022-02-04 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)
SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Solvay Advanced Polymers, LLC')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Vopak Terminals Savannah Inc')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);


INSERT INTO [dbo].[Order] ([OrderTypeID], [FacilityID], [OrderStatusID], [GasDate], [EffectiveTime], [OrderCreatedDate])
VALUES (@OrderTypeID, @FacilityID, 1, '2022-02-27', '2022-02-27 10:00:00.000', GETDATE());


SET @OrderId = (
		SELECT TOP 1 OrderID
		FROM [dbo].[Order]
		ORDER BY OrderID DESC
		)

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='Vopak Terminals Savannah Inc')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

SET @CustomerId=(Select CustomerID from dbo.[Customer] Where LongName='C W Matthews - Bolingbroke')
INSERT INTO [dbo].[OrderConnection] ([OrderID], [AggregatePoolID], [CustomerID])
VALUES (@OrderID, @AggrigatePoolID, @CustomerId);

